<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Topbar Start -->
    <div class="container-fluid d-none d-lg-block">
        <div class="row align-items-center py-4 px-xl-5">
            <div class="col-lg-3">
                <a href="https://www.abuhureira.sc.ke" class="text-decoration-none">
                    <img src="img/logo.png" style="height: 150px; ">
                   
                </a>
            </div>
            <div class="col-lg-3 text-right">
                <div class="d-inline-flex align-items-center">
                    <i class="fa fa-2x fa-map-marker-alt text-primary mr-3"></i>
                    <div class="text-left">
                        <h6 class="font-weight-semi-bold mb-1">Our Office</h6>
                       <small> <a href="mhttps://www.google.com/maps/dir/-4.047358,39.656789/Abu+Hureira+Academy,+Off,+Dar+Es+Salam+Rd,+Mombasa,+Kenya/@-4.0473538,39.574387,12z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x184012cbde2fc481:0x35a9f7cc17f2a894!2m2!1d39.656789!2d-4.047358?entry=ttu">Off, Dar Es Salam Rd, Mombasa </a></small> 
                    </div>
                </div>
            </div>
            <div class="col-lg-3 text-right">
                <div class="d-inline-flex align-items-center">
                    <i class="fa fa-2x fa-envelope text-primary mr-3"></i>
                    <div class="text-left">
                        <h6 class="font-weight-semi-bold mb-1">Email Us</h6>
                      <small> <a href="mailto:info@abuhureira.sc.ke">Abuhureira Info </a></small> 
                    </div>
                </div>
            </div>
            <div class="col-lg-3 text-right">
                <div class="d-inline-flex align-items-center">
                    <i class="fa fa-2x fa-phone text-primary mr-3"></i>
                    <div class="text-left">
                        <h6 class="font-weight-semi-bold mb-1">Call Us</h6>
                        <small>+254 722 844902</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->
<style>
h4, .h4 {
    
    color: white;
}
.text-primary {
    color: #ffffff!important;
}
    .nav-item{
        
        
    }
    .navbar-light .navbar-nav .nav-link:hover, .navbar-light .navbar-nav .nav-link.active {
    color: blue;
    font-size:90%;
}

</style>

    <!-- Navbar Start -->
    <div class="container-fluid">
        <div class="row border-top px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a class="d-flex align-items-center justify-content-between bg-secondary w-100 text-decoration-none" data-toggle="collapse" href="#navbar-vertical" style="height: 67px; padding: 0 30px;">
                    <h5 class="text-primary m-0"><i class="fa fa-book-open mr-2"></i>Curriculums</h5>
                    <i class="fa fa-angle-down text-primary"></i>
                </a>
                <nav class="collapse position-absolute navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0 bg-light" id="navbar-vertical" style="width: calc(100% - 30px); z-index: 9;">
                    <div class="navbar-nav w-100">
                        <div class="nav-item dropdown">
                            <a href="" class="nav-item nav-link">8-4-4</a>
                            <div class="dropdown-menu position-absolute bg-secondary border-0 rounded-0 w-100 m-0">
                               
                            </div>
                        </div>
                        <a href="" class="nav-item nav-link">Junior Secondary</a>
                        <a href="" class="nav-item nav-link">IGCSE</a>

                        <a href="" class="nav-item nav-link">Madrasa</a>
                        
                    </div>
                </nav>
            </div>
            <div class="col-lg-9">
                <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
                    <a href="" class="text-decoration-none d-block d-lg-none">
                        <img src="img/logo.png" style="height: 100px; ">
                    </a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav py-0">
                            <a href="index.html" class="nav-item nav-link active">Home</a>
                            <a href="https://drive.google.com/drive/folders/1z3-fuUhdLO8hFJ_lsVULs8LqunIttEAh?usp=sharing" class="nav-item nav-link active">Library </a>
                            <a href="https://www.youtube.com/playlist?list=PLmaHFDzMAJh67aiGee5EDEI5mMiIvFjJq" class="nav-item nav-link active">Youtube Library  </a>
                            <a href="https://www.abuhureira.sc.ke/student"  class="nav-item nav-link active">Check Your Results↓</a>
                        </div>
                        
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- Navbar End -->
    <style>
        .card-header{
            background:blue;
            color:white;
            font-family: Arial, Helvetica, sans-serif;
        }
        .h20{
            
            color: green;
        }
    </style>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">

                <div class="card mt-5">
                    <div class="card-header text-center ">
                        <h4>Abuhureira Online Results</h4>
                        <h20>Contact 0726993726 For Enquiries</h20>
                    </div>
                    <div class="card-body">

                        <form action="" method="GET">
                            <div class="row">
                                <div class="col-md-8">
                                    <input type="text" name="stud_id" value="<?php if(isset($_GET['stud_id'])){echo $_GET['stud_id'];} ?>" class="form-control">
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary">Search</button>
                                    
                                </div>
                               
                                
                            </div>
                             
                        </form>

                        <div class="row">
                            <div class="col-md-12">
                                <hr>
                                <?php 
                                    $con = mysqli_connect("localhost","abuhurei_abdi","sonik9200","abuhurei_student");
                                    
                                    

                                    if(isset($_GET['stud_id']))
                                    {
                                        $stud_id = $_GET['stud_id'];

                                        $query = "SELECT * FROM student WHERE id='$stud_id' ";
                                        $query_run = mysqli_query($con, $query);

                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $row)
                                            {
                                                ?>
                                                <div class="form-group mb-3">
                                                    <label for="">Name</label>
                                                    <input type="text" value="<?= $row['stud_name']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Class</label>
                                                    <input type="text" value="<?= $row['stud_class']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">English</label>
                                                    <input type="text" value="<?= $row['stud_english']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Mathematics</label>
                                                    <input type="text" value="<?= $row['stud_mathematics']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Kiswahili</label>
                                                    <input type="text" value="<?= $row['stud_kiswahili']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Ire</label>
                                                    <input type="text" value="<?= $row['stud_ire']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Business</label>
                                                    <input type="text" value="<?= $row['stud_business']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">History</label>
                                                    <input type="text" value="<?= $row['stud_history']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Chemistry</label>
                                                    <input type="text" value="<?= $row['stud_chemistry']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Physics</label>
                                                    <input type="text" value="<?= $row['stud_physics']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Biology</label>
                                                    <input type="text" value="<?= $row['stud_biology']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Literature</label>
                                                    <input type="text" value="<?= $row['stud_literature']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Arabic</label>
                                                    <input type="text" value="<?= $row['stud_arabic']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Total</label>
                                                    <input type="text" value="<?= $row['stud_total']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Average</label>
                                                    <input type="text" value="<?= $row['stud_average']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Grade</label>
                                                    <input type="text" value="<?= $row['stud_grade']; ?>" class="form-control">
                                                </div>
                                               
                                                <?php
                                                
                                            }
                                        }
                                        else
                                        {
                                            echo "No Record Found";
                                        }
                                    }
                                   
                                ?>
                                <?php 
                                    $con = mysqli_connect("localhost","abuhurei_abdi","sonik9200","abuhurei_midterm");
                                    
                                    

                                    if(isset($_GET['stud_id']))
                                    {
                                        $stud_id = $_GET['stud_id'];

                                        $query = "SELECT * FROM student WHERE id='$stud_id' ";
                                        $query_run = mysqli_query($con, $query);

                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $row)
                                            {
                                                ?>
                                                <div class="form-group mb-3">
                                                    <label for="">Name</label>
                                                    <input type="text" value="<?= $row['stud_name']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Class</label>
                                                    <input type="text" value="<?= $row['stud_class']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">English</label>
                                                    <input type="text" value="<?= $row['stud_english']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Mathematics</label>
                                                    <input type="text" value="<?= $row['stud_mathematics']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Kiswahili</label>
                                                    <input type="text" value="<?= $row['stud_kiswahili']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Ire</label>
                                                    <input type="text" value="<?= $row['stud_ire']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Business</label>
                                                    <input type="text" value="<?= $row['stud_business']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">History</label>
                                                    <input type="text" value="<?= $row['stud_history']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Chemistry</label>
                                                    <input type="text" value="<?= $row['stud_chemistry']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Physics</label>
                                                    <input type="text" value="<?= $row['stud_physics']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Biology</label>
                                                    <input type="text" value="<?= $row['stud_biology']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Literature</label>
                                                    <input type="text" value="<?= $row['stud_literature']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Arabic</label>
                                                    <input type="text" value="<?= $row['stud_arabic']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Total</label>
                                                    <input type="text" value="<?= $row['stud_total']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Average</label>
                                                    <input type="text" value="<?= $row['stud_average']; ?>" class="form-control">
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="">Grade</label>
                                                    <input type="text" value="<?= $row['stud_grade']; ?>" class="form-control">
                                                </div>
                                               
                                                <?php
                                                
                                            }
                                        }
                                        else
                                        {
                                            echo "No Record Found";
                                        }
                                    }
                                   
                                ?>

                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <style>
        .btn1 {
  background: #3498db;
  background-image: -webkit-linear-gradient(top, #3498db, #2980b9);
  background-image: -moz-linear-gradient(top, #3498db, #2980b9);
  background-image: -ms-linear-gradient(top, #3498db, #2980b9);
  background-image: -o-linear-gradient(top, #3498db, #2980b9);
  background-image: linear-gradient(to bottom, #3498db, #2980b9);
  -webkit-border-radius: 0;
  -moz-border-radius: 0;
  border-radius: 0px;
  font-family: Arial;
  color: #ffffff;
  font-size: 16px;
  background: #3498db;
  padding: 10px 40px 9px 40px;
  text-decoration: none;
}

.btn:hover {
  background: #000000;
  text-decoration: none;
}
</style>

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white py-5 px-sm-3 px-lg-5" style="margin-top: 90px;">
        <div class="row pt-5">
            <div class="col-lg-7 col-md-12">
                <div class="row">
                    <div class="col-md-6 mb-5">
                        <h5 class="text-primary text-uppercase mb-4" style="letter-spacing: 5px;">Get In Touch</h5>
                        <p><i class="fa fa-map-marker-alt mr-2"></i>Off, Dar Es Salam Rd, Mombasa</p>
                        <p><i class="fa fa-phone-alt mr-2"></i>+254 722 844902</p>
                        <p><i class="fa fa-envelope mr-2"></i>info@abuhureira.sc.ke</p>
                        <div class="d-flex justify-content-start mt-4">
                           
                            <a class="btn btn-outline-light btn-square mr-2" href="https://web.facebook.com/abuhureiraacademy"><i class="fab fa-facebook-f"></i></a>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="col-lg-5 col-md-12 mb-5">
                <h5 class="text-primary text-uppercase mb-4" style="letter-spacing: 5px;">Notice Board Signup</h5>
                <div class="w-100">
                    <div class="input-group">
                        <input type="text" class="form-control border-light" style="padding: 30px;" placeholder="Your Email Address">
                        <div class="input-group-append">
                            <button class="btn btn-primary px-4">Sign Up</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid bg-dark text-white border-top py-4 px-sm-3 px-md-5" style="border-color: rgba(256, 256, 256, .1) !important;">
        <div class="row">
            <div class="col-lg-6 text-center text-md-left mb-3 mb-md-0">
                <p class="m-0 text-white">&copy; <a href="www.abuhureira.sc.ke">Abuhureira Academy</a>. All Rights Reserved. Designed by <a href="https://web.facebook.com/Nasir.cabdi/">Abuhureira Academy</a>
                </p>
            </div>
            <div class="col-lg-6 text-center text-md-right">
                <ul class="nav d-inline-flex">
                    <li class="nav-item">
                        <a class="nav-link text-white py-0" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white py-0" href="#">About</a>
                    </li>
                   
                </ul>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>
</html>